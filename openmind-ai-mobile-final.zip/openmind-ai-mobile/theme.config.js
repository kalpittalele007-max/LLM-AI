/** @type {const} */
const themeColors = {
  primary: { light: '#6C8A16', dark: '#D7F264' },
  background: { light: '#F6F8F3', dark: '#0E1110' },
  surface: { light: '#FFFFFF', dark: '#151A18' },
  foreground: { light: '#162019', dark: '#F5F7EF' },
  muted: { light: '#65736A', dark: '#9BA79F' },
  border: { light: '#DDE5DC', dark: '#2A352F' },
  success: { light: '#1F8B62', dark: '#8FE3BF' },
  warning: { light: '#B56D09', dark: '#F6C76A' },
  error: { light: '#B83B47', dark: '#FF8992' },
};

module.exports = { themeColors };
