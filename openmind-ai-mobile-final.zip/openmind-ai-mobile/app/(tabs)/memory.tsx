import { useState } from "react";
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { OpenMindMark, SectionHeading, StatusPill, SurfaceCard } from "@/components/openmind-ui";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";

export default function MemoryScreen() {
  const colors = useColors();
  const [note, setNote] = useState("");
  const memory = trpc.memory.list.useQuery();
  const add = trpc.memory.add.useMutation({ onSuccess: () => { setNote(""); memory.refetch(); } });

  function save() {
    if (note.trim() && !add.isPending) add.mutate({ content: note.trim(), tags: ["context"] });
  }

  return (
    <ScreenContainer className="px-5" containerClassName="bg-background">
      <View style={styles.header}><OpenMindMark compact /><StatusPill label={`${memory.data?.items.length ?? 0} saved`} tone="muted" /></View>
      <View style={styles.intro}><SectionHeading eyebrow="Personal context" title="Memory that helps." detail="Save preferences, project details, or decisions you want OpenMind to remember." /></View>
      <View style={[styles.addBox, { backgroundColor: colors.surface, borderColor: colors.border }]}><TextInput value={note} onChangeText={setNote} placeholder="OpenMind should remember that…" placeholderTextColor={colors.muted} multiline style={[styles.noteInput, { color: colors.foreground }]} /><Pressable disabled={!note.trim() || add.isPending} onPress={save} style={({ pressed }) => [styles.saveButton, { backgroundColor: note.trim() ? colors.primary : colors.border }, pressed && { opacity: 0.7 }]}>{add.isPending ? <ActivityIndicator color={colors.background} size="small" /> : <IconSymbol name="plus" size={18} color={note.trim() ? colors.background : colors.muted} />}</Pressable></View>
      <FlatList
        data={memory.data?.items ?? []}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.list}
        refreshing={memory.isRefetching}
        onRefresh={() => memory.refetch()}
        ListHeaderComponent={<Text style={[styles.listLabel, { color: colors.muted }]}>SAVED CONTEXT</Text>}
        ListEmptyComponent={<SurfaceCard><View style={styles.empty}><IconSymbol name="brain.head.profile" size={28} color={colors.primary} /><Text style={[styles.emptyTitle, { color: colors.foreground }]}>Your memory is clear.</Text><Text style={[styles.emptyText, { color: colors.muted }]}>Saved research and notes will appear here.</Text></View></SurfaceCard>}
        renderItem={({ item }) => <SurfaceCard style={styles.memoryCard}><View style={styles.memoryTop}><View style={[styles.kindIcon, { backgroundColor: `${colors.primary}1A` }]}><IconSymbol name={item.kind === "research" ? "magnifyingglass" : "bookmark.fill"} size={15} color={colors.primary} /></View><Text style={[styles.kind, { color: colors.primary }]}>{item.kind}</Text><Text style={[styles.date, { color: colors.muted }]}>{new Date(item.createdAt).toLocaleDateString()}</Text></View><Text style={[styles.memoryText, { color: colors.foreground }]}>{item.content}</Text>{item.tags?.length > 0 && <View style={styles.tags}>{item.tags.map((tag: string) => <Text key={tag} style={[styles.tag, { color: colors.muted, borderColor: colors.border }]}>{tag}</Text>)}</View>}</SurfaceCard>}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingTop: 8 },
  intro: { paddingTop: 18, paddingBottom: 18 },
  addBox: { flexDirection: "row", alignItems: "flex-end", borderWidth: 1, borderRadius: 18, padding: 8, paddingLeft: 14, gap: 8 },
  noteInput: { flex: 1, minHeight: 46, maxHeight: 100, fontSize: 14, lineHeight: 20, paddingTop: 8 },
  saveButton: { width: 38, height: 38, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  list: { gap: 12, paddingTop: 22, paddingBottom: 30, flexGrow: 1 },
  listLabel: { fontSize: 10, letterSpacing: 1.3, fontWeight: "800", marginBottom: 1 },
  memoryCard: { padding: 14 },
  memoryTop: { flexDirection: "row", alignItems: "center", gap: 7, marginBottom: 10 },
  kindIcon: { width: 26, height: 26, borderRadius: 9, alignItems: "center", justifyContent: "center" },
  kind: { fontSize: 11, fontWeight: "800", textTransform: "uppercase", letterSpacing: 0.6 },
  date: { fontSize: 11, marginLeft: "auto" },
  memoryText: { fontSize: 14, lineHeight: 21 },
  tags: { flexDirection: "row", gap: 6, marginTop: 12 },
  tag: { fontSize: 10, borderWidth: 1, borderRadius: 999, paddingVertical: 4, paddingHorizontal: 7 },
  empty: { alignItems: "center", gap: 8, paddingVertical: 22 },
  emptyTitle: { fontSize: 15, fontWeight: "700" },
  emptyText: { fontSize: 13, textAlign: "center" },
});
