import { useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Switch, Text, TextInput, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { OpenMindMark, SectionHeading, StatusPill, SurfaceCard } from "@/components/openmind-ui";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";

const suggestions = ["What changed in AI this year?", "Compare React Native and Flutter", "Explain quantum computing simply"];

export default function ResearchScreen() {
  const colors = useColors();
  const [query, setQuery] = useState("");
  const [saveToMemory, setSaveToMemory] = useState(true);
  const research = trpc.research.run.useMutation();
  const pattern = trpc.research.prepare.useQuery({ query }, { enabled: query.trim().length > 4 });
  const result = research.data as any;

  async function run() {
    if (!query.trim() || research.isPending) return;
    await research.mutateAsync({ query: query.trim(), saveToMemory });
  }

  return (
    <ScreenContainer className="px-5" containerClassName="bg-background">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <View style={styles.topbar}><OpenMindMark compact /><StatusPill label="source-aware" /></View>
        <SectionHeading eyebrow="Deep work" title="Research with receipts." detail="Ask a question. OpenMind gathers public evidence, compares signals, and shows where uncertainty remains." />
        <View style={[styles.searchBox, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <IconSymbol name="magnifyingglass" size={20} color={colors.muted} />
          <TextInput value={query} onChangeText={setQuery} onSubmitEditing={run} returnKeyType="search" placeholder="What do you want to understand?" placeholderTextColor={colors.muted} style={[styles.searchInput, { color: colors.foreground }]} />
          <Pressable disabled={!query.trim() || research.isPending} onPress={run} style={({ pressed }) => [styles.runButton, { backgroundColor: query.trim() ? colors.primary : colors.border }, pressed && { opacity: 0.7 }]}>{research.isPending ? <ActivityIndicator size="small" color={colors.background} /> : <IconSymbol name="arrow.up" size={18} color={query.trim() ? colors.background : colors.muted} />}</Pressable>
        </View>
        {pattern.data && <View style={[styles.patternRow, { backgroundColor: `${colors.primary}12`, borderColor: `${colors.primary}35` }]}><IconSymbol name="sparkles" size={15} color={colors.primary} /><Text style={[styles.patternText, { color: colors.foreground }]}>{pattern.data.label} · {pattern.data.plan[0]}</Text></View>}
        {!result && <View style={styles.suggestionSection}><Text style={[styles.label, { color: colors.muted }]}>START WITH A QUESTION</Text>{suggestions.map((item) => <Pressable key={item} onPress={() => setQuery(item)} style={({ pressed }) => [styles.suggestion, { borderColor: colors.border }, pressed && { opacity: 0.7 }]}><Text style={[styles.suggestionText, { color: colors.foreground }]}>{item}</Text><IconSymbol name="chevron.right" size={16} color={colors.primary} /></Pressable>)}</View>}
        {result && <ResearchResult result={result} colors={colors} />}
        <View style={[styles.memoryToggle, { borderTopColor: colors.border }]}><View style={styles.toggleCopy}><IconSymbol name="bookmark.fill" size={16} color={colors.primary} /><View><Text style={[styles.toggleTitle, { color: colors.foreground }]}>Save to memory</Text><Text style={[styles.toggleDetail, { color: colors.muted }]}>Use this research in future answers</Text></View></View><Switch value={saveToMemory} onValueChange={setSaveToMemory} trackColor={{ false: colors.border, true: `${colors.primary}88` }} thumbColor={saveToMemory ? colors.primary : colors.muted} /></View>
      </ScrollView>
    </ScreenContainer>
  );
}

function ResearchResult({ result, colors }: { result: any; colors: ReturnType<typeof useColors> }) {
  const sources = Array.isArray(result.sources) ? result.sources : [];
  return <View style={styles.resultWrap}>
    <View style={styles.resultHeader}><View style={{ flex: 1 }}><Text style={[styles.label, { color: colors.primary }]}>RESEARCH BRIEF</Text><Text style={[styles.resultTitle, { color: colors.foreground }]}>{result.title || "Evidence-backed answer"}</Text></View><StatusPill label={result.verification?.verdict === "pass" ? "verified" : "needs review"} tone={result.verification?.verdict === "pass" ? "success" : "warning"} /></View>
    <SurfaceCard accent><Text style={[styles.answer, { color: colors.foreground }]}>{result.answer || result.summary || "No answer returned."}</Text></SurfaceCard>
    {!!result.caveats && <SurfaceCard><Text style={[styles.label, { color: colors.muted }]}>CAVEATS</Text><Text style={[styles.body, { color: colors.foreground }]}>{result.caveats}</Text></SurfaceCard>}
    <View style={styles.statsRow}><Stat label="sources" value={String(result.provenance?.sourceCount ?? sources.length)} colors={colors} /><Stat label="fetched" value={String(result.provenance?.fetchedCount ?? 0)} colors={colors} /><Stat label="memory" value={result.provenance?.memoryUsed ? "used" : "new"} colors={colors} /></View>
    <View style={styles.sourcesWrap}><Text style={[styles.label, { color: colors.muted }]}>SOURCE TRAIL</Text>{sources.slice(0, 5).map((source: any, index: number) => <View key={`${source.url}-${index}`} style={[styles.sourceRow, { borderBottomColor: colors.border }]}><View style={[styles.sourceNumber, { backgroundColor: `${colors.primary}1A` }]}><Text style={[styles.sourceNumberText, { color: colors.primary }]}>{index + 1}</Text></View><View style={{ flex: 1 }}><Text numberOfLines={2} style={[styles.sourceTitle, { color: colors.foreground }]}>{source.title || source.url}</Text><Text numberOfLines={1} style={[styles.sourceUrl, { color: colors.muted }]}>{source.url}</Text></View></View>)}</View>
  </View>;
}
function Stat({ label, value, colors }: { label: string; value: string; colors: ReturnType<typeof useColors> }) { return <View style={[styles.stat, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.statValue, { color: colors.primary }]}>{value}</Text><Text style={[styles.statLabel, { color: colors.muted }]}>{label}</Text></View>; }

const styles = StyleSheet.create({
  content: { paddingTop: 8, paddingBottom: 30, gap: 18 },
  topbar: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  searchBox: { flexDirection: "row", alignItems: "center", gap: 9, borderWidth: 1, borderRadius: 18, padding: 7, paddingLeft: 14 },
  searchInput: { flex: 1, minHeight: 40, fontSize: 15 },
  runButton: { width: 40, height: 40, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  patternRow: { flexDirection: "row", alignItems: "center", gap: 8, borderWidth: 1, borderRadius: 12, padding: 11 },
  patternText: { flex: 1, fontSize: 12, fontWeight: "600" },
  suggestionSection: { gap: 10, paddingTop: 4 },
  label: { fontSize: 10, letterSpacing: 1.3, fontWeight: "800" },
  suggestion: { minHeight: 50, flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderWidth: 1, borderRadius: 15, paddingHorizontal: 14 },
  suggestionText: { fontSize: 14, fontWeight: "600" },
  resultWrap: { gap: 13 },
  resultHeader: { flexDirection: "row", alignItems: "flex-start", gap: 10 },
  resultTitle: { fontSize: 20, lineHeight: 25, fontWeight: "700", marginTop: 5 },
  answer: { fontSize: 16, lineHeight: 24 },
  body: { fontSize: 14, lineHeight: 21, marginTop: 8 },
  statsRow: { flexDirection: "row", gap: 9 },
  stat: { flex: 1, borderWidth: 1, borderRadius: 14, paddingVertical: 12, paddingHorizontal: 10 },
  statValue: { fontSize: 17, fontWeight: "800" },
  statLabel: { fontSize: 11, marginTop: 2 },
  sourcesWrap: { gap: 10 },
  sourceRow: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 10, borderBottomWidth: 1 },
  sourceNumber: { width: 26, height: 26, borderRadius: 9, alignItems: "center", justifyContent: "center" },
  sourceNumberText: { fontWeight: "800", fontSize: 12 },
  sourceTitle: { fontSize: 13, lineHeight: 18, fontWeight: "600" },
  sourceUrl: { fontSize: 11, marginTop: 3 },
  memoryToggle: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderTopWidth: 1, paddingTop: 16 },
  toggleCopy: { flexDirection: "row", alignItems: "center", gap: 10 },
  toggleTitle: { fontSize: 13, fontWeight: "700" },
  toggleDetail: { fontSize: 11, marginTop: 2 },
});
