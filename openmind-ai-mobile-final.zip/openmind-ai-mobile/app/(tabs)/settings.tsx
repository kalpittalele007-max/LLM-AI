import { ScrollView, StyleSheet, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { OpenMindMark, SectionHeading, StatusPill, SurfaceCard } from "@/components/openmind-ui";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";

const capabilityIcons: Record<string, "sparkles" | "magnifyingglass" | "brain.head.profile" | "doc.text"> = {
  "secure AI chat": "sparkles",
  "evidence-backed research": "magnifyingglass",
  "saved memory": "brain.head.profile",
  "website blueprints": "doc.text",
};

export default function SettingsScreen() {
  const colors = useColors();
  const capabilities = trpc.capabilities.useQuery();
  return (
    <ScreenContainer className="px-5" containerClassName="bg-background">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <View style={styles.header}><OpenMindMark compact /><StatusPill label="v1 mobile" tone="muted" /></View>
        <SectionHeading eyebrow="Workspace" title="Built for thoughtful work." detail="A native surface for the OpenMind platform you uploaded, with server-side AI and clear safety boundaries." />
        <SurfaceCard accent><View style={styles.runtimeHeader}><View style={[styles.shield, { backgroundColor: `${colors.success}1A` }]}><IconSymbol name="shield.fill" size={21} color={colors.success} /></View><View style={{ flex: 1 }}><Text style={[styles.cardTitle, { color: colors.foreground }]}>Secure AI runtime</Text><Text style={[styles.cardDetail, { color: colors.muted }]}>Credentials stay on the server. The app only sends the conversation you choose to share.</Text></View></View><View style={[styles.runtimeStatus, { borderTopColor: colors.border }]}><StatusPill label="online" /><Text style={[styles.runtimeText, { color: colors.muted }]}>OpenMind model gateway</Text></View></SurfaceCard>
        <View style={styles.section}><Text style={[styles.sectionLabel, { color: colors.muted }]}>WHAT’S INSIDE</Text>{(capabilities.data?.supports ?? ["secure AI chat", "evidence-backed research", "saved memory", "website blueprints"]).map((item) => <View key={item} style={[styles.capability, { borderBottomColor: colors.border }]}><View style={[styles.capIcon, { backgroundColor: `${colors.primary}1A` }]}><IconSymbol name={capabilityIcons[item] ?? "sparkles"} size={16} color={colors.primary} /></View><Text style={[styles.capabilityText, { color: colors.foreground }]}>{item}</Text><IconSymbol name="checkmark" size={17} color={colors.success} /></View>)}</View>
        <View style={styles.section}><Text style={[styles.sectionLabel, { color: colors.muted }]}>PRIVACY PROMISE</Text><SurfaceCard><Text style={[styles.privacyQuote, { color: colors.foreground }]}>“Useful enough to help. Honest enough to trust.”</Text><Text style={[styles.body, { color: colors.muted }]}>OpenMind is designed to say what it knows, show evidence for research, and refuse unsafe requests. Important decisions still deserve human judgment.</Text></SurfaceCard></View>
        <Text style={[styles.footer, { color: colors.muted }]}>OpenMind AI · Native mobile workspace</Text>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingTop: 8, paddingBottom: 32, gap: 20 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  runtimeHeader: { flexDirection: "row", gap: 12, alignItems: "flex-start" },
  shield: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  cardTitle: { fontSize: 16, fontWeight: "700", marginBottom: 4 },
  cardDetail: { fontSize: 13, lineHeight: 19 },
  runtimeStatus: { flexDirection: "row", alignItems: "center", gap: 10, borderTopWidth: 1, marginTop: 15, paddingTop: 13 },
  runtimeText: { fontSize: 12, fontWeight: "600" },
  section: { gap: 10 },
  sectionLabel: { fontSize: 10, letterSpacing: 1.3, fontWeight: "800" },
  capability: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 12, borderBottomWidth: 1 },
  capIcon: { width: 30, height: 30, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  capabilityText: { flex: 1, fontSize: 14, fontWeight: "600" },
  privacyQuote: { fontSize: 17, fontWeight: "700", lineHeight: 23, marginBottom: 10 },
  body: { fontSize: 13, lineHeight: 20 },
  footer: { textAlign: "center", fontSize: 11, lineHeight: 17, paddingHorizontal: 16 },
});
