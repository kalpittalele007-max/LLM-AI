import { useEffect, useMemo, useRef, useState } from "react";
import { ActivityIndicator, Alert, FlatList, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import * as Location from "expo-location";
import * as Speech from "expo-speech";
import { type Region } from "react-native-maps";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { OpenMindMark, SectionHeading, StatusPill } from "@/components/openmind-ui";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";
import { queueRouteFeedback, registerMapsFeedbackSync } from "@/lib/maps-background-task";
import { NativeMap } from "@/components/native-map";

type Coordinate = { latitude: number; longitude: number };
type RouteOption = { id: string; distanceMeters: number; durationSeconds: number; geometry: Coordinate[]; steps: (Coordinate & { instruction: string; distanceMeters: number; durationSeconds: number; roadName: string })[] };
type RoutePlan = RouteOption & { attribution: string; alternatives: RouteOption[] };

const fallbackLocation: Coordinate = { latitude: 20.5937, longitude: 78.9629 };
const distanceBetween = (a: Coordinate, b: Coordinate) => { const dLat = (a.latitude - b.latitude) * 111_000; const dLon = (a.longitude - b.longitude) * 111_000 * Math.cos((a.latitude * Math.PI) / 180); return Math.sqrt(dLat * dLat + dLon * dLon); };
const formatDistance = (meters: number) => meters >= 1000 ? `${(meters / 1000).toFixed(1)} km` : `${Math.max(10, Math.round(meters / 10) * 10)} m`;
const formatDuration = (seconds: number) => `${Math.max(1, Math.round(seconds / 60))} min`;

export default function MapsScreen() {
  const colors = useColors();
  const [origin, setOrigin] = useState<Coordinate | null>(null);
  const [destinationText, setDestinationText] = useState("");
  const [destination, setDestination] = useState<Coordinate | null>(null);
  const [destinationLabel, setDestinationLabel] = useState("");
  const [routePlan, setRoutePlan] = useState<RoutePlan | null>(null);
  const [navigating, setNavigating] = useState(false);
  const [locationError, setLocationError] = useState("");
  const [learningEnabled, setLearningEnabled] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [lastSpokenStep, setLastSpokenStep] = useState(-1);
  const mapRef = useRef<any>(null);
  const watchRef = useRef<Location.LocationSubscription | null>(null);
  const geocode = trpc.maps.geocode.useMutation();
  const route = trpc.maps.route.useMutation();
  const feedback = trpc.maps.feedback.useMutation();

  useEffect(() => { return () => { watchRef.current?.remove(); Speech.stop(); }; }, []);
  useEffect(() => { (async () => { const permission = await Location.requestForegroundPermissionsAsync(); if (permission.status !== "granted") { setLocationError("Location permission is needed for turn-by-turn navigation."); return; } const current = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced }); setOrigin({ latitude: current.coords.latitude, longitude: current.coords.longitude }); })(); }, []);

  const mapRegion: Region = useMemo(() => ({ latitude: origin?.latitude ?? fallbackLocation.latitude, longitude: origin?.longitude ?? fallbackLocation.longitude, latitudeDelta: 0.08, longitudeDelta: 0.08 }), [origin]);

  async function findRoute() {
    if (!destinationText.trim()) return;
    try {
      const places = await geocode.mutateAsync({ query: destinationText.trim() });
      const first = places[0];
      if (!first) throw new Error("No matching destination found.");
      const start = origin ?? fallbackLocation;
      const planned = await route.mutateAsync({ origin: start, destination: first.coordinate });
      setDestination(first.coordinate); setDestinationLabel(first.label); setRoutePlan(planned as RoutePlan); setCurrentStep(0); setLastSpokenStep(-1);
      mapRef.current?.fitToCoordinates((planned as RoutePlan).geometry, { edgePadding: { top: 90, right: 36, bottom: 330, left: 36 }, animated: true });
    } catch (error) { Alert.alert("Route unavailable", error instanceof Error ? error.message : "Please try another destination."); }
  }

  async function speakCurrentStep(index = currentStep) { const step = routePlan?.steps[index]; if (!step) return; await Speech.stop(); Speech.speak(step.instruction, { rate: 0.92 }); setLastSpokenStep(index); }

  async function startNavigation() {
    if (!routePlan) return;
    setNavigating(true);
    if (learningEnabled) await registerMapsFeedbackSync();
    await speakCurrentStep(0);
    if (Platform.OS === "web") return;
    watchRef.current = await Location.watchPositionAsync({ accuracy: Location.Accuracy.High, distanceInterval: 12, timeInterval: 5000 }, async (position) => {
      const here = { latitude: position.coords.latitude, longitude: position.coords.longitude };
      setOrigin(here);
      const nextIndex = routePlan.steps.findIndex((step, index) => index >= currentStep && distanceBetween(here, step) < 45);
      if (nextIndex >= 0 && nextIndex !== currentStep) { setCurrentStep(nextIndex); if (nextIndex !== lastSpokenStep) await speakCurrentStep(nextIndex); }
    });
  }

  async function stopNavigation(outcome: "completed" | "rerouted" | "skipped" = "completed") {
    watchRef.current?.remove(); watchRef.current = null; setNavigating(false); await Speech.stop();
    if (routePlan && learningEnabled) { const sample = { routeId: routePlan.id, outcome, durationSeconds: routePlan.durationSeconds, deviationMeters: 0 }; await queueRouteFeedback(sample); feedback.mutate(sample); }
  }

  const isWorking = geocode.isPending || route.isPending;
  return (
    <ScreenContainer edges={["top", "left", "right"]} containerClassName="bg-background" className="px-5">
      <View style={styles.header}><OpenMindMark compact /><StatusPill label={navigating ? "navigating" : "live location"} tone={navigating ? "success" : "muted"} /></View>
      <View style={styles.title}><SectionHeading eyebrow="OpenMind Maps" title="Every turn, spoken clearly." detail="Live location, route geometry, and step-by-step instructions. Location stays on-device unless you opt into anonymous route-quality learning." /></View>
      <View style={[styles.searchBox, { backgroundColor: colors.surface, borderColor: colors.border }]}><IconSymbol name="map.fill" size={19} color={colors.muted} /><TextInput value={destinationText} onChangeText={setDestinationText} onSubmitEditing={findRoute} placeholder="Where do you want to go?" placeholderTextColor={colors.muted} style={[styles.searchInput, { color: colors.foreground }]} /><Pressable disabled={isWorking || !destinationText.trim()} onPress={findRoute} style={({ pressed }) => [styles.goButton, { backgroundColor: destinationText.trim() ? colors.primary : colors.border }, pressed && { opacity: 0.7 }]}>{isWorking ? <ActivityIndicator size="small" color={colors.background} /> : <IconSymbol name="arrow.up" size={18} color={destinationText.trim() ? colors.background : colors.muted} />}</Pressable></View>
      {locationError ? <View style={[styles.notice, { backgroundColor: `${colors.warning}18`, borderColor: `${colors.warning}55` }]}><IconSymbol name="location.fill" size={16} color={colors.warning} /><Text style={[styles.noticeText, { color: colors.foreground }]}>{locationError}</Text></View> : null}
      {Platform.OS === "web" ? <View style={[styles.webMap, { backgroundColor: colors.surface, borderColor: colors.border }]}><IconSymbol name="map.fill" size={30} color={colors.primary} /><Text style={[styles.webMapTitle, { color: colors.foreground }]}>Native map preview</Text><Text style={[styles.webMapText, { color: colors.muted }]}>Open this project in an Android/iOS development build to render the interactive map. Route instructions still work in the web preview.</Text></View> : <NativeMap style={styles.map} initialRegion={mapRegion} showsUserLocation showsMyLocationButton={false} origin={origin} destination={destination} geometry={routePlan?.geometry} colors={{ primary: colors.primary }} />}
      {routePlan ? <View style={styles.routePanel}><View style={styles.routeSummary}><View><Text style={[styles.routeTitle, { color: colors.foreground }]}>{destinationLabel.split(",")[0] || "Your route"}</Text><Text style={[styles.routeMeta, { color: colors.muted }]}>{formatDistance(routePlan.distanceMeters)} · {formatDuration(routePlan.durationSeconds)} · {routePlan.steps.length} turns</Text></View><Pressable onPress={() => speakCurrentStep()} style={({ pressed }) => [styles.speakButton, { backgroundColor: `${colors.primary}1A` }, pressed && { opacity: 0.7 }]}><IconSymbol name="speaker.wave.2.fill" size={18} color={colors.primary} /></Pressable></View>{routePlan.alternatives.length ? <View style={styles.alternativeRow}><Text style={[styles.alternativeLabel, { color: colors.muted }]}>OTHER ROUTES</Text><ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.alternativeList}>{routePlan.alternatives.map((option, index) => <Pressable key={option.id} onPress={() => setRoutePlan((current) => current ? { ...option, attribution: current.attribution, alternatives: [current, ...current.alternatives.filter((item) => item.id !== option.id)] } : current)} style={({ pressed }) => [styles.alternativeCard, { borderColor: colors.border, backgroundColor: colors.surface }, pressed && { opacity: 0.7 }]}><Text style={[styles.alternativeTitle, { color: colors.foreground }]}>Route {index + 2}</Text><Text style={[styles.alternativeMeta, { color: colors.muted }]}>{formatDistance(option.distanceMeters)} · {formatDuration(option.durationSeconds)}</Text></Pressable>)}</ScrollView></View> : null}<View style={styles.actionRow}><Pressable onPress={navigating ? () => stopNavigation("completed") : startNavigation} style={({ pressed }) => [styles.primaryAction, { backgroundColor: colors.primary }, pressed && { transform: [{ scale: 0.98 }] }]}><IconSymbol name={navigating ? "stop.fill" : "paperplane.up.fill"} size={16} color={colors.background} /><Text style={[styles.primaryActionText, { color: colors.background }]}>{navigating ? "Stop navigation" : "Start navigation"}</Text></Pressable><Pressable onPress={() => stopNavigation("rerouted")} style={({ pressed }) => [styles.secondaryAction, { borderColor: colors.border }, pressed && { opacity: 0.7 }]}><Text style={[styles.secondaryActionText, { color: colors.foreground }]}>Reset</Text></Pressable></View><View style={styles.stepsHeader}><Text style={[styles.label, { color: colors.muted }]}>TURN-BY-TURN</Text><Text style={[styles.stepProgress, { color: colors.primary }]}>{Math.min(currentStep + 1, routePlan.steps.length)} / {routePlan.steps.length}</Text></View><FlatList data={routePlan.steps} keyExtractor={(_, index) => `${index}`} scrollEnabled={false} renderItem={({ item, index }) => <View style={[styles.stepRow, { borderBottomColor: colors.border }, index === currentStep && { backgroundColor: `${colors.primary}12` }]}><View style={[styles.stepNumber, { backgroundColor: index === currentStep ? colors.primary : colors.border }]}><Text style={[styles.stepNumberText, { color: index === currentStep ? colors.background : colors.muted }]}>{index + 1}</Text></View><View style={{ flex: 1 }}><Text style={[styles.stepText, { color: colors.foreground }]}>{item.instruction}</Text><Text style={[styles.stepMeta, { color: colors.muted }]}>{formatDistance(item.distanceMeters)} · {formatDuration(item.durationSeconds)}</Text></View><Pressable onPress={() => speakCurrentStep(index)}><IconSymbol name="speaker.wave.2.fill" size={17} color={colors.muted} /></Pressable></View>} /><Text style={[styles.attribution, { color: colors.muted }]}>{routePlan.attribution}</Text></View> : null}
      <View style={[styles.learningRow, { borderColor: colors.border }]}><View style={[styles.learningIcon, { backgroundColor: `${colors.primary}1A` }]}><IconSymbol name="sparkles" size={15} color={colors.primary} /></View><View style={{ flex: 1 }}><Text style={[styles.learningTitle, { color: colors.foreground }]}>Help improve routes</Text><Text style={[styles.learningText, { color: colors.muted }]}>{learningEnabled ? "Opted in: only anonymous route outcomes sync in the background." : "Off by default. No raw location history is uploaded."}</Text></View><Pressable onPress={() => setLearningEnabled((value) => !value)} style={({ pressed }) => [styles.toggle, { backgroundColor: learningEnabled ? colors.primary : colors.border }, pressed && { opacity: 0.7 }]}><View style={[styles.toggleKnob, { backgroundColor: colors.background, transform: [{ translateX: learningEnabled ? 17 : 2 }] }]} /></Pressable></View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({ flex: { flex: 1 }, header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingTop: 8 }, title: { paddingTop: 18, paddingBottom: 14 }, searchBox: { flexDirection: "row", alignItems: "center", gap: 8, borderWidth: 1, borderRadius: 17, padding: 7, paddingLeft: 13 }, searchInput: { flex: 1, minHeight: 40, fontSize: 15 }, goButton: { width: 40, height: 40, borderRadius: 14, alignItems: "center", justifyContent: "center" }, notice: { flexDirection: "row", alignItems: "center", gap: 8, borderWidth: 1, borderRadius: 12, padding: 10, marginTop: 10 }, noticeText: { flex: 1, fontSize: 12, lineHeight: 18 }, map: { height: 220, borderRadius: 20, marginTop: 14 }, webMap: { height: 180, borderWidth: 1, borderRadius: 20, marginTop: 14, alignItems: "center", justifyContent: "center", padding: 22, gap: 7 }, webMapTitle: { fontSize: 16, fontWeight: "700" }, webMapText: { fontSize: 12, lineHeight: 18, textAlign: "center" }, routePanel: { marginTop: 14, gap: 12 }, alternativeRow: { gap: 7 }, alternativeLabel: { fontSize: 10, fontWeight: "800", letterSpacing: 1.2 }, alternativeList: { gap: 8 }, alternativeCard: { borderWidth: 1, borderRadius: 12, paddingVertical: 8, paddingHorizontal: 10, minWidth: 108 }, alternativeTitle: { fontSize: 12, fontWeight: "800" }, alternativeMeta: { fontSize: 10, marginTop: 3 }, routeSummary: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" }, routeTitle: { fontSize: 18, fontWeight: "700" }, routeMeta: { fontSize: 12, marginTop: 4 }, speakButton: { width: 38, height: 38, borderRadius: 13, alignItems: "center", justifyContent: "center" }, actionRow: { flexDirection: "row", gap: 8 }, primaryAction: { flex: 1, minHeight: 45, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, borderRadius: 14 }, primaryActionText: { fontSize: 13, fontWeight: "800" }, secondaryAction: { minHeight: 45, paddingHorizontal: 15, borderWidth: 1, borderRadius: 14, alignItems: "center", justifyContent: "center" }, secondaryActionText: { fontSize: 13, fontWeight: "700" }, stepsHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 4 }, label: { fontSize: 10, fontWeight: "800", letterSpacing: 1.3 }, stepProgress: { fontSize: 11, fontWeight: "800" }, stepRow: { flexDirection: "row", alignItems: "center", gap: 9, paddingVertical: 10, paddingHorizontal: 8, borderBottomWidth: 1, borderRadius: 10 }, stepNumber: { width: 25, height: 25, borderRadius: 9, alignItems: "center", justifyContent: "center" }, stepNumberText: { fontSize: 11, fontWeight: "800" }, stepText: { fontSize: 13, lineHeight: 18, fontWeight: "600" }, stepMeta: { fontSize: 11, marginTop: 2 }, attribution: { textAlign: "right", fontSize: 10 }, learningRow: { flexDirection: "row", alignItems: "center", gap: 9, borderWidth: 1, borderRadius: 16, padding: 11, marginTop: 14, marginBottom: 10 }, learningIcon: { width: 28, height: 28, borderRadius: 10, alignItems: "center", justifyContent: "center" }, learningTitle: { fontSize: 12, fontWeight: "800" }, learningText: { fontSize: 10, lineHeight: 15, marginTop: 2 }, toggle: { width: 37, height: 21, borderRadius: 11, justifyContent: "center" }, toggleKnob: { width: 17, height: 17, borderRadius: 9 },
});
