import { useMemo, useRef, useState } from "react";
import { ActivityIndicator, FlatList, KeyboardAvoidingView, Platform, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { ModeChip, OpenMindMark, StatusPill } from "@/components/openmind-ui";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";

type Mode = "ask" | "coach" | "code";
type Message = { id: string; role: "user" | "assistant"; content: string };

const starters = ["Explain a difficult idea simply", "Help me plan my next project", "Review this code with me"];
const initialMessages: Message[] = [{ id: "welcome", role: "assistant", content: "I’m OpenMind. Ask me anything, or switch modes when you want a different kind of thinking." }];

export default function AskScreen() {
  const colors = useColors();
  const [mode, setMode] = useState<Mode>("ask");
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const listRef = useRef<FlatList<Message>>(null);
  const chat = trpc.chat.useMutation();
  const canSend = input.trim().length > 0 && !chat.isPending;
  const modeLabel = useMemo(() => ({ ask: "Ask", coach: "Coach", code: "Code" })[mode], [mode]);

  async function sendMessage(value = input) {
    const content = value.trim();
    if (!content || chat.isPending) return;
    const userMessage: Message = { id: `${Date.now()}-user`, role: "user", content };
    const next = [...messages, userMessage];
    setMessages(next);
    setInput("");
    requestAnimationFrame(() => listRef.current?.scrollToEnd({ animated: true }));
    try {
      const response = await chat.mutateAsync({ mode, messages: next.map(({ role, content: text }) => ({ role, content: text })) });
      setMessages((current) => [...current, { id: `${Date.now()}-assistant`, role: "assistant", content: response.content || "I couldn’t produce a response this time." }]);
    } catch (error) {
      setMessages((current) => [...current, { id: `${Date.now()}-error`, role: "assistant", content: `I hit a connection issue. ${error instanceof Error ? error.message : "Please try again."}` }]);
    }
    requestAnimationFrame(() => listRef.current?.scrollToEnd({ animated: true }));
  }

  return (
    <ScreenContainer edges={["top", "left", "right"]} containerClassName="bg-background" className="px-5">
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : undefined} keyboardVerticalOffset={88}>
        <View style={styles.header}>
          <OpenMindMark />
          <StatusPill label="secure runtime" />
        </View>
        <View style={styles.modeRow}>
          <ModeChip label="Ask" icon="sparkles" active={mode === "ask"} onPress={() => setMode("ask")} />
          <ModeChip label="Coach" icon="brain.head.profile" active={mode === "coach"} onPress={() => setMode("coach")} />
          <ModeChip label="Code" icon="chevron.left.forwardslash.chevron.right" active={mode === "code"} onPress={() => setMode("code")} />
        </View>
        <FlatList
          ref={listRef}
          data={messages}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.chatContent}
          showsVerticalScrollIndicator={false}
          onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: false })}
          renderItem={({ item }) => (
            <View style={[styles.messageRow, item.role === "user" && styles.userRow]}>
              {item.role === "assistant" && <View style={[styles.avatar, { backgroundColor: `${colors.primary}22` }]}><IconSymbol name="sparkles" size={16} color={colors.primary} /></View>}
              <View style={[styles.bubble, { backgroundColor: item.role === "user" ? colors.primary : colors.surface, borderColor: item.role === "user" ? colors.primary : colors.border }]}>
                <Text style={[styles.messageText, { color: item.role === "user" ? colors.background : colors.foreground }]}>{item.content}</Text>
              </View>
            </View>
          )}
          ListEmptyComponent={<View />}
          ListFooterComponent={
            messages.length === 1 ? (
              <View style={styles.starterWrap}>
                <Text style={[styles.starterLabel, { color: colors.muted }]}>TRY A STARTER</Text>
                {starters.map((starter) => <Pressable key={starter} onPress={() => sendMessage(starter)} style={({ pressed }) => [styles.starter, { borderColor: colors.border, backgroundColor: colors.surface }, pressed && { opacity: 0.7 }]}><Text style={[styles.starterText, { color: colors.foreground }]}>{starter}</Text><IconSymbol name="arrow.up" size={15} color={colors.primary} /></Pressable>)}
              </View>
            ) : null
          }
        />
        <View style={[styles.composer, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <TextInput value={input} onChangeText={setInput} onSubmitEditing={() => sendMessage()} returnKeyType="send" blurOnSubmit={false} multiline placeholder={`Message OpenMind in ${modeLabel} mode…`} placeholderTextColor={colors.muted} style={[styles.input, { color: colors.foreground }]} />
          <Pressable disabled={!canSend} onPress={() => sendMessage()} style={({ pressed }) => [styles.sendButton, { backgroundColor: canSend ? colors.primary : colors.border }, pressed && { transform: [{ scale: 0.94 }] }]}>
            {chat.isPending ? <ActivityIndicator size="small" color={colors.background} /> : <IconSymbol name="arrow.up" size={18} color={canSend ? colors.background : colors.muted} />}
          </Pressable>
        </View>
        <Text style={[styles.disclaimer, { color: colors.muted }]}>AI can make mistakes. Check important decisions with trusted sources.</Text>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingTop: 8, paddingBottom: 18 },
  modeRow: { flexDirection: "row", gap: 8, paddingBottom: 12 },
  chatContent: { flexGrow: 1, paddingTop: 8, paddingBottom: 18, gap: 12 },
  messageRow: { flexDirection: "row", alignItems: "flex-start", gap: 9, maxWidth: "92%" },
  userRow: { alignSelf: "flex-end", justifyContent: "flex-end" },
  avatar: { width: 30, height: 30, borderRadius: 10, alignItems: "center", justifyContent: "center", marginTop: 2 },
  bubble: { borderWidth: 1, borderRadius: 18, paddingHorizontal: 14, paddingVertical: 12, maxWidth: "100%" },
  messageText: { fontSize: 15, lineHeight: 22 },
  starterWrap: { gap: 9, paddingTop: 20 },
  starterLabel: { fontSize: 10, letterSpacing: 1.4, fontWeight: "800", marginBottom: 2 },
  starter: { minHeight: 46, flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderWidth: 1, borderRadius: 14, paddingHorizontal: 13 },
  starterText: { fontSize: 13, fontWeight: "600" },
  composer: { flexDirection: "row", alignItems: "flex-end", borderWidth: 1, borderRadius: 19, padding: 7, paddingLeft: 14, gap: 8 },
  input: { flex: 1, minHeight: 38, maxHeight: 110, fontSize: 15, lineHeight: 21, paddingTop: 8, paddingBottom: 8 },
  sendButton: { width: 38, height: 38, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  disclaimer: { textAlign: "center", fontSize: 10, paddingVertical: 8 },
});
