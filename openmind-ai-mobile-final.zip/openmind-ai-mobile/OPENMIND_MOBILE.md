# OpenMind AI Mobile

OpenMind AI Mobile is the native Expo client created from the uploaded Kalpit OpenMind AI platform and Android prototype.

## Product surface

- **Ask:** server-backed AI conversation with Ask, Coach, and Code modes.
- **Research:** source-aware research using intent classification, evidence grading, verification, and provenance logic.
- **Memory:** durable saved context backed by the existing file-based memory module.
- **Maps:** foreground location permission, destination search, route geometry, spoken turn-by-turn instructions, and an explicit navigation session.
- **Settings:** runtime status, privacy posture, and current capability inventory.

## Maps and speech

The app uses `expo-speech` for local device text-to-speech, so no speech API key is required. Route search uses public Nominatim geocoding and OSRM driving routes by default, so development does not require a paid map-service key. Production deployments should review provider quotas and usage policies.

The interactive native map uses `react-native-maps` on Android and iOS. The browser preview intentionally shows a native-map placeholder because the native map module is not available on web. If you choose Google Maps rendering for a production Android build, create a restricted Google Maps SDK key, restrict it to the package `com.openmind.ai.mobile` and the release SHA-1, then add native map manifest metadata or a supported config plugin before building the release binary. The routing engine and spoken instructions do not depend on Google Maps.

## Background route learning

Background route learning is **opt-in**. It queues only aggregate route outcomes such as `completed`, `rerouted`, or `skipped` and syncs them through a platform background task. It does not upload raw continuous location histories or silently track people. Android and iOS decide when deferred background work runs; it is not guaranteed to run immediately. Users can turn the setting off, and queued samples remain local until the task succeeds.

## Architecture

The client uses Expo Router, React Native, NativeWind-compatible theme tokens, TanStack Query, and tRPC. AI credentials remain server-side through the built-in LLM helper. The original platform's research, memory, security, and website blueprint modules are reused behind the new server boundary.

## Validation

Run:

```bash
pnpm check
pnpm test -- --run
pnpm build
```

The project is configured for Expo SDK 54 and includes `index.html` for the web entry point.
