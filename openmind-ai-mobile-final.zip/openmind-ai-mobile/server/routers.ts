import { z } from "zod";
import { invokeLLM } from "./_core/llm";
import { router, publicProcedure } from "./_core/trpc";
import { systemRouter } from "./_core/systemRouter";
import { appendMemory, readMemory } from "./memory";
import { recognizePattern, rememberResearch, runResearch } from "./research";
import { buildWebsiteBlueprint } from "./websiteBuilder";
import { geocode, recordRouteFeedback, route } from "./maps";

const userIdFromContext = (ctx: { user?: { id: number } | null }) => ctx.user?.id ?? 0;
function contentToText(content: unknown): string {
  if (typeof content === "string") return content;
  if (Array.isArray(content)) return content.map((part) => typeof part === "string" ? part : part && typeof part === "object" && "text" in part ? String(part.text ?? "") : "").join("").trim();
  return String(content ?? "");
}
const chatMessage = z.object({ role: z.enum(["user", "assistant", "system"]), content: z.string().min(1).max(20_000) });
const coordinate = z.object({ latitude: z.number().min(-90).max(90), longitude: z.number().min(-180).max(180) });

export const appRouter = router({
  system: systemRouter,
  auth: router({ me: publicProcedure.query(({ ctx }) => ctx.user), logout: publicProcedure.mutation(() => ({ success: true } as const)) }),
  chat: publicProcedure.input(z.object({ messages: z.array(chatMessage).min(1).max(60), mode: z.enum(["ask", "coach", "code"]).default("ask") })).mutation(async ({ input, ctx }) => {
    const memory = await readMemory(userIdFromContext(ctx), 8);
    const memoryContext = memory.length ? `\nRelevant saved context (use only when helpful):\n${memory.map((item) => `- ${item.content}`).join("\n")}` : "";
    const modeInstruction = { ask: "Answer clearly and directly. State uncertainty instead of inventing facts.", coach: "Teach step by step, using plain language and a short practical next step.", code: "Act as a careful senior developer. Give runnable, secure examples and mention assumptions and test steps." }[input.mode];
    const response = await invokeLLM({ messages: [{ role: "system", content: `You are OpenMind, a thoughtful multimodal AI assistant. ${modeInstruction} You cannot access private device data unless the user shares it. Never claim an action was completed when you only suggested it.${memoryContext}` }, ...input.messages] });
    return { content: contentToText(response.choices[0]?.message.content), mode: input.mode, createdAt: new Date().toISOString() };
  }),
  research: router({
    prepare: publicProcedure.input(z.object({ query: z.string().max(2_000) })).query(({ input }) => recognizePattern(input.query)),
    run: publicProcedure.input(z.object({ query: z.string().min(1).max(2_000), saveToMemory: z.boolean().default(true) })).mutation(async ({ input, ctx }) => { const userId = userIdFromContext(ctx); const result = await runResearch(input.query, true, userId); if (input.saveToMemory && result.stance !== "boundary") await rememberResearch(userId, input.query, result.answer); return result; }),
  }),
  memory: router({
    list: publicProcedure.query(async ({ ctx }) => ({ items: await readMemory(userIdFromContext(ctx), 50) })),
    add: publicProcedure.input(z.object({ content: z.string().min(1).max(4_000), tags: z.array(z.string()).max(8).default(["context"]) })).mutation(({ input, ctx }) => appendMemory(userIdFromContext(ctx), { kind: "context", content: input.content, tags: input.tags })),
  }),
  maps: router({
    geocode: publicProcedure.input(z.object({ query: z.string().min(2).max(300) })).mutation(({ input }) => geocode(input.query)),
    route: publicProcedure.input(z.object({ origin: coordinate, destination: coordinate })).mutation(({ input }) => route(input.origin, input.destination)),
    feedback: publicProcedure.input(z.object({ routeId: z.string().min(1).max(100), outcome: z.enum(["completed", "rerouted", "skipped"]), deviationMeters: z.number().min(0).max(100_000).optional(), durationSeconds: z.number().min(0).max(86_400).optional() })).mutation(({ input }) => recordRouteFeedback(input)),
  }),
  websites: router({ blueprint: publicProcedure.input(z.object({ prompt: z.string().min(8).max(2_000), framework: z.enum(["react", "html", "next"]).default("react") })).mutation(({ input }) => buildWebsiteBlueprint(input.prompt, input.framework)) }),
  capabilities: publicProcedure.query(() => ({ name: "OpenMind", supports: ["secure AI chat", "evidence-backed research", "saved memory", "website blueprints", "multimodal server LLM", "turn-by-turn maps", "spoken navigation", "opt-in anonymous route learning"], refuses: ["sandbox escape", "credential exfiltration", "unsafe destructive commands", "silent location tracking"], status: "ready" })),
});
export type AppRouter = typeof appRouter;
