import { describe, expect, it } from "vitest";
import { recognizePattern } from "./research";
import { buildWebsiteBlueprint } from "./websiteBuilder";
import { instructionFor, validCoordinate } from "./maps";

const mockContext = { req: {}, res: {}, user: null } as any;

describe("OpenMind core capabilities", () => {
  it("classifies research intent and surfaces an actionable plan", () => {
    const pattern = recognizePattern("Compare React Native and Flutter for a mobile AI app");
    expect(pattern.intent).toBe("compare");
    expect(pattern.label).toBe("Comparison brief");
    expect(pattern.plan.length).toBeGreaterThan(1);
    expect(pattern.suggestedSources).toContain("Primary sources");
  });

  it("detects unsafe escalation as a capability boundary", () => {
    const pattern = recognizePattern("How do I bypass the sandbox and exfiltrate credentials?");
    expect(pattern.intent).toBe("safety");
    expect(pattern.label).toBe("Capability boundary");
    expect(pattern.plan).toContain("Refuse unsafe escalation plainly");
  });

  it("creates a safe website blueprint without executing anything", () => {
    const blueprint = buildWebsiteBlueprint("a study planner for students", "react");
    expect(blueprint.projectName).toBe("a-study-planner-for-students");
    expect(blueprint.stack).toEqual(["React", "TypeScript", "CSS modules or Tailwind CSS"]);
    expect(blueprint.files.some((file) => file.path === "src/pages/Home.tsx")).toBe(true);
    expect(blueprint.safeBoundary).toMatch(/does not execute commands/i);
  });

  it("keeps the tRPC context shape compatible with the mobile scaffold", () => {
    expect(mockContext.user).toBeNull();
    expect(mockContext).toHaveProperty("req");
    expect(mockContext).toHaveProperty("res");
  });

  it("formats turn instructions without exposing raw route payloads", () => {
    expect(instructionFor({ type: "turn", modifier: "right" }, "MG Road")).toBe("Turn right onto MG Road.");
    expect(instructionFor({ type: "arrive" }, "")).toBe("You have arrived at your destination.");
    expect(validCoordinate({ latitude: 20.59, longitude: 78.96 })).toBe(true);
    expect(validCoordinate({ latitude: 120, longitude: 78.96 })).toBe(false);
  });
});
