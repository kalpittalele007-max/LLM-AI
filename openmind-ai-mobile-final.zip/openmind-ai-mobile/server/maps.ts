import fs from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";

export type Coordinate = { latitude: number; longitude: number };
export type RouteStep = Coordinate & {
  instruction: string;
  distanceMeters: number;
  durationSeconds: number;
  roadName: string;
  maneuverType: string;
};
export type RoutePlan = {
  id: string;
  distanceMeters: number;
  durationSeconds: number;
  geometry: Coordinate[];
  steps: RouteStep[];
  provider: "OSRM";
  attribution: string;
  alternatives: Array<Pick<RoutePlan, "id" | "distanceMeters" | "durationSeconds" | "geometry" | "steps">>;
};

type GeocodeResult = { label: string; coordinate: Coordinate };
const feedbackPath = path.resolve(process.cwd(), "data", "maps-feedback.json");
const userAgent = "OpenMind-AI-Mobile/1.0 (route-planning)";

export function validCoordinate(value: Coordinate) {
  return Number.isFinite(value.latitude) && Number.isFinite(value.longitude) && Math.abs(value.latitude) <= 90 && Math.abs(value.longitude) <= 180;
}

export function instructionFor(maneuver: any, roadName: string) {
  const type = String(maneuver?.type ?? "continue");
  const modifier = String(maneuver?.modifier ?? "").replaceAll("_", " ");
  const road = roadName ? ` onto ${roadName}` : "";
  if (type === "arrive") return "You have arrived at your destination.";
  if (type === "depart") return roadName ? `Start by heading ${modifier || "ahead"}${road}.` : "Start by following the route.";
  if (type === "roundabout" || type === "rotary") return `Enter the roundabout${road}.`;
  if (type === "new name" || type === "continue") return `Continue ${modifier || "straight"}${road}.`;
  return `${type.charAt(0).toUpperCase()}${type.slice(1)} ${modifier}${road}.`.replace(/  /g, " ");
}

export async function geocode(query: string): Promise<GeocodeResult[]> {
  const response = await fetch(`https://nominatim.openstreetmap.org/search?format=jsonv2&limit=5&q=${encodeURIComponent(query.trim())}`, { headers: { "User-Agent": userAgent } });
  if (!response.ok) throw new Error(`Geocoding failed (${response.status})`);
  const rows = (await response.json()) as Array<{ display_name: string; lat: string; lon: string }>;
  return rows.map((row) => ({ label: row.display_name, coordinate: { latitude: Number(row.lat), longitude: Number(row.lon) } })).filter((row) => validCoordinate(row.coordinate));
}

export async function route(origin: Coordinate, destination: Coordinate): Promise<RoutePlan> {
  if (!validCoordinate(origin) || !validCoordinate(destination)) throw new Error("A valid origin and destination are required.");
  const url = `https://router.project-osrm.org/route/v1/driving/${origin.longitude},${origin.latitude};${destination.longitude},${destination.latitude}?overview=full&geometries=geojson&steps=true&alternatives=true`;
  const response = await fetch(url, { headers: { "User-Agent": userAgent } });
  if (!response.ok) throw new Error(`Routing failed (${response.status})`);
  const payload = (await response.json()) as any;
  const providerRoutes = Array.isArray(payload.routes) ? payload.routes : [];
  if (!providerRoutes.length) throw new Error("No drivable route was found.");
  const buildOption = (candidate: any) => {
    const geometry = (candidate.geometry?.coordinates ?? []).map(([longitude, latitude]: [number, number]) => ({ latitude, longitude })).filter(validCoordinate);
    const steps: RouteStep[] = (candidate.legs?.[0]?.steps ?? []).map((step: any) => {
      const [longitude, latitude] = step.maneuver?.location ?? [0, 0];
      const roadName = String(step.name ?? "").trim();
      return { latitude, longitude, roadName, maneuverType: String(step.maneuver?.type ?? "continue"), instruction: instructionFor(step.maneuver, roadName), distanceMeters: Math.round(Number(step.distance ?? 0)), durationSeconds: Math.round(Number(step.duration ?? 0)) };
    }).filter(validCoordinate);
    return { id: randomUUID(), distanceMeters: Math.round(candidate.distance ?? 0), durationSeconds: Math.round(candidate.duration ?? 0), geometry, steps };
  };
  const options = providerRoutes.map(buildOption);
  const selected = options[0];
  return { ...selected, provider: "OSRM", attribution: "Routing © OpenStreetMap contributors · OSRM", alternatives: options.slice(1) };
}

export async function recordRouteFeedback(input: { routeId: string; outcome: "completed" | "rerouted" | "skipped"; deviationMeters?: number; durationSeconds?: number }) {
  await fs.mkdir(path.dirname(feedbackPath), { recursive: true });
  let items: Array<Record<string, unknown>> = [];
  try { items = JSON.parse(await fs.readFile(feedbackPath, "utf8")); } catch { items = []; }
  items.push({ ...input, deviationMeters: Math.max(0, Math.round(input.deviationMeters ?? 0)), durationSeconds: Math.max(0, Math.round(input.durationSeconds ?? 0)), recordedAt: new Date().toISOString() });
  await fs.writeFile(feedbackPath, JSON.stringify(items.slice(-5000), null, 2) + "\n", "utf8");
  return { accepted: true, aggregateOnly: true, queuedSamples: items.length };
}
