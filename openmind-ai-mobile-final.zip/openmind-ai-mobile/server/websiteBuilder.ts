export type WebsiteBlueprint = {
  projectName: string;
  summary: string;
  stack: string[];
  pages: Array<{ name: string; purpose: string; components: string[] }>;
  components: Array<{ name: string; purpose: string; props: string[] }>;
  files: Array<{ path: string; purpose: string; starter: string }>;
  accessibility: string[];
  security: string[];
  nextSteps: string[];
  safeBoundary: string;
};

const slugify = (value: string) => value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 42) || "openmind-site";

export function buildWebsiteBlueprint(prompt: string, framework: "react" | "html" | "next" = "react"): WebsiteBlueprint {
  const name = prompt.split(/\s+/).slice(0, 5).join(" ").replace(/[^a-zA-Z0-9 &'’-]/g, "").trim() || "New Website";
  const stack = framework === "html" ? ["HTML", "CSS", "Vanilla JavaScript"] : framework === "next" ? ["Next.js", "TypeScript", "Tailwind CSS"] : ["React", "TypeScript", "CSS modules or Tailwind CSS"];
  return {
    projectName: slugify(name),
    summary: `A polished ${framework === "html" ? "semantic static" : "component-based"} website plan for: ${prompt.trim()}`,
    stack,
    pages: [
      { name: "Home", purpose: "Explain the value proposition and guide the visitor to the main action.", components: ["SiteHeader", "HeroSection", "FeatureGrid", "CallToAction", "SiteFooter"] },
      { name: "About", purpose: "Build trust with story, proof, and team or process information.", components: ["Breadcrumbs", "StorySection", "MetricsStrip", "SiteFooter"] },
      { name: "Contact", purpose: "Collect a clear, accessible inquiry without exposing secrets.", components: ["ContactForm", "ValidationMessage", "ContactDetails", "SiteFooter"] },
    ],
    components: [
      { name: "SiteHeader", purpose: "Responsive navigation with keyboard support.", props: ["brand", "links", "primaryAction"] },
      { name: "HeroSection", purpose: "High-clarity headline, supporting copy, and primary action.", props: ["eyebrow", "title", "description", "actions", "media"] },
      { name: "FeatureGrid", purpose: "Scannable benefits with consistent visual hierarchy.", props: ["items", "columns"] },
      { name: "ContactForm", purpose: "Validated contact fields with explicit submission states.", props: ["fields", "onSubmit", "status"] },
      { name: "SiteFooter", purpose: "Secondary navigation, legal links, and copyright.", props: ["links", "socials"] },
    ],
    files: [
      { path: "src/components/SiteHeader.tsx", purpose: "Responsive accessible header", starter: "export function SiteHeader() { return <header aria-label=\"Main navigation\">...</header>; }" },
      { path: "src/components/HeroSection.tsx", purpose: "Primary landing section", starter: "export function HeroSection({ title }: { title: string }) { return <section><h1>{title}</h1></section>; }" },
      { path: "src/pages/Home.tsx", purpose: "Home page composition", starter: "export default function Home() { return <><SiteHeader /><HeroSection title=\"Your headline\" /></>; }" },
      { path: "src/styles/tokens.css", purpose: "Central design tokens", starter: ":root { --color-bg: #101512; --color-accent: #d9f38b; --radius: 12px; }" },
      { path: "tests/home.spec.ts", purpose: "Smoke and accessibility regression tests", starter: "test('home renders a main heading', async () => { /* add browser test */ });" },
    ],
    accessibility: ["Use one clear h1 per page", "Visible keyboard focus states", "Labels and error text for every form field", "Respect reduced-motion preferences", "Meet WCAG color contrast targets"],
    security: ["Validate all form input on the server", "Never place API keys in client code", "Add CSRF protection for state-changing requests", "Rate-limit public forms", "Do not render unsanitized HTML"],
    nextSteps: ["Confirm the target audience and primary conversion", "Choose brand colors, type scale, and imagery", "Implement the shared components before page-specific sections", "Add content and responsive visual checks", "Run type checks, tests, accessibility checks, and a production build"],
    safeBoundary: "This planner creates a blueprint and starter snippets only. It does not execute commands, publish a site, change accounts, or leave the current sandbox.",
  };
}
