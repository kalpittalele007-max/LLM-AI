/**
 * OpenMind app runtime bridge for safe-area updates in an embedded web preview.
 * The bridge is inert on native platforms and outside an embedding iframe.
 */
import { Platform } from "react-native";
import type { Metrics } from "react-native-safe-area-context";

const DEBUG = false;
const log = (message: string) => { if (DEBUG) console.log(`[OpenMindRuntime] ${message}`); };
type MessageType = "appDevServerReady";
type SafeAreaInsets = { top: number; right: number; bottom: number; left: number };
type SafeAreaCallback = (metrics: Metrics) => void;
interface PreviewMessage { type: "SpacePreviewerChannel"; payload: { type: string; from: "container" | "content"; to: "container" | "content"; payload: Record<string, unknown> } }

function isInIframe() { if (Platform.OS !== "web") return false; try { return window.self !== window.top; } catch { return true; } }
function isWeb() { return Platform.OS === "web"; }
function sendToParent(type: MessageType, payload: Record<string, unknown> = {}) {
  if (!isWeb() || !isInIframe()) return;
  const message: PreviewMessage = { type: "SpacePreviewerChannel", payload: { type, from: "content", to: "container", payload } };
  window.parent.postMessage(message, "*");
  log(`Sent ${type}`);
}
let initialized = false;
let safeAreaCallback: SafeAreaCallback | null = null;
function isValidInsets(payload: Record<string, unknown>): payload is SafeAreaInsets { return typeof payload.top === "number" && typeof payload.bottom === "number" && typeof payload.left === "number" && typeof payload.right === "number"; }
function handleMessage(event: MessageEvent<unknown>) {
  const data = event.data as PreviewMessage | undefined;
  if (!data || data.type !== "SpacePreviewerChannel" || !data.payload || data.payload.to !== "content") return;
  if (data.payload.type === "setSafeAreaInsets" && isValidInsets(data.payload.payload) && safeAreaCallback) {
    const insets = data.payload.payload;
    safeAreaCallback({ insets, frame: { x: 0, y: 0, width: window.innerWidth, height: window.innerHeight } });
  }
}
export function subscribeSafeAreaInsets(callback: SafeAreaCallback) { safeAreaCallback = callback; return () => { if (safeAreaCallback === callback) safeAreaCallback = null; }; }
export function initAppRuntime() { if (!isWeb() || !isInIframe() || initialized) return; initialized = true; window.addEventListener("message", handleMessage); sendToParent("appDevServerReady"); }
export function isRunningInPreviewIframe() { return isWeb() && isInIframe(); }
