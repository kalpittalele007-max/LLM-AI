import AsyncStorage from "@react-native-async-storage/async-storage";
import * as BackgroundTask from "expo-background-task";
import * as TaskManager from "expo-task-manager";
import { getApiBaseUrl } from "@/constants/oauth";

export const MAPS_FEEDBACK_TASK = "openmind-maps-feedback-sync";
const QUEUE_KEY = "openmind.maps.feedback.queue";

type Feedback = { routeId: string; outcome: "completed" | "rerouted" | "skipped"; deviationMeters?: number; durationSeconds?: number };

async function readQueue(): Promise<Feedback[]> {
  try { return JSON.parse((await AsyncStorage.getItem(QUEUE_KEY)) || "[]") as Feedback[]; } catch { return []; }
}
export async function queueRouteFeedback(feedback: Feedback) {
  const queue = await readQueue();
  await AsyncStorage.setItem(QUEUE_KEY, JSON.stringify([...queue, feedback].slice(-100)));
}

TaskManager.defineTask(MAPS_FEEDBACK_TASK, async () => {
  try {
    const queue = await readQueue();
    if (!queue.length) return BackgroundTask.BackgroundTaskResult.Success;
    const remaining: Feedback[] = [];
    for (const feedback of queue) {
      try {
        const response = await fetch(`${getApiBaseUrl()}/api/trpc/maps.feedback`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ json: feedback }) });
        if (!response.ok) remaining.push(feedback);
      } catch { remaining.push(feedback); }
    }
    await AsyncStorage.setItem(QUEUE_KEY, JSON.stringify(remaining));
    return remaining.length < queue.length ? BackgroundTask.BackgroundTaskResult.Success : BackgroundTask.BackgroundTaskResult.Failed;
  } catch {
    return BackgroundTask.BackgroundTaskResult.Failed;
  }
});

export async function registerMapsFeedbackSync() {
  if (!(await TaskManager.isTaskRegisteredAsync(MAPS_FEEDBACK_TASK))) {
    await BackgroundTask.registerTaskAsync(MAPS_FEEDBACK_TASK, { minimumInterval: 15 * 60 });
  }
}
export async function unregisterMapsFeedbackSync() {
  if (await TaskManager.isTaskRegisteredAsync(MAPS_FEEDBACK_TASK)) await BackgroundTask.unregisterTaskAsync(MAPS_FEEDBACK_TASK);
}
