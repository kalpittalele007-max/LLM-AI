// Fallback for using MaterialIcons on Android and web.
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { SymbolWeight } from "expo-symbols";
import { ComponentProps } from "react";
import { OpaqueColorValue, type StyleProp, type TextStyle } from "react-native";
const MAPPING = {
  "house.fill": "home", "paperplane.fill": "send", "chevron.left.forwardslash.chevron.right": "code", "chevron.right": "chevron-right", "sparkles": "auto-awesome", "magnifyingglass": "search", "brain.head.profile": "psychology", "gearshape.fill": "settings", "plus": "add", "bookmark.fill": "bookmark", "shield.fill": "shield", "arrow.up": "arrow-upward", "checkmark": "check", "clock": "schedule", "doc.text": "description", "map.fill": "map", "paperplane.up.fill": "navigation", "speaker.wave.2.fill": "volume-up", "stop.fill": "stop", "location.fill": "my-location"
} as const satisfies Record<string, ComponentProps<typeof MaterialIcons>["name"]>;
type IconSymbolName = keyof typeof MAPPING;
export function IconSymbol({ name, size = 24, color, style }: { name: IconSymbolName; size?: number; color: string | OpaqueColorValue; style?: StyleProp<TextStyle>; weight?: SymbolWeight }) {
  return <MaterialIcons color={color} size={size} name={MAPPING[name]} style={style} />;
}
