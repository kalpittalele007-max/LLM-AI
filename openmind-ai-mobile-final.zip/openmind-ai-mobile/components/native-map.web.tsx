import { View } from "react-native";
import type { MapViewProps } from "react-native-maps";
type Coordinate = { latitude: number; longitude: number };
type Props = MapViewProps & { origin?: Coordinate | null; destination?: Coordinate | null; geometry?: Coordinate[]; colors: { primary: string } };
export function NativeMap(_props: Props) { return <View />; }
