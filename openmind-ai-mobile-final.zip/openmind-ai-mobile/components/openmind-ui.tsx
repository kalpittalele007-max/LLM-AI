import { ReactNode } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";

export function OpenMindMark({ compact = false }: { compact?: boolean }) {
  const colors = useColors();
  return (
    <View style={styles.brandRow}>
      <View style={[styles.brandMark, { backgroundColor: colors.primary }]}>
        <IconSymbol name="sparkles" size={compact ? 16 : 19} color={colors.background} />
      </View>
      {!compact && <Text style={[styles.brandName, { color: colors.foreground }]}>OpenMind</Text>}
    </View>
  );
}

export function SectionHeading({ eyebrow, title, detail }: { eyebrow?: string; title: string; detail?: string }) {
  const colors = useColors();
  return (
    <View style={styles.headingWrap}>
      {eyebrow && <Text style={[styles.eyebrow, { color: colors.primary }]}>{eyebrow.toUpperCase()}</Text>}
      <Text style={[styles.heading, { color: colors.foreground }]}>{title}</Text>
      {detail && <Text style={[styles.detail, { color: colors.muted }]}>{detail}</Text>}
    </View>
  );
}

export function SurfaceCard({ children, style, accent = false }: { children: ReactNode; style?: object; accent?: boolean }) {
  const colors = useColors();
  return (
    <View style={[styles.card, { backgroundColor: colors.surface, borderColor: accent ? colors.primary : colors.border }, style]}>
      {children}
    </View>
  );
}

export function ModeChip({ label, icon, active, onPress }: { label: string; icon: "sparkles" | "brain.head.profile" | "chevron.left.forwardslash.chevron.right"; active: boolean; onPress: () => void }) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.modeChip,
        { borderColor: active ? colors.primary : colors.border, backgroundColor: active ? `${colors.primary}1A` : colors.surface },
        pressed && styles.pressed,
      ]}
    >
      <IconSymbol name={icon} size={15} color={active ? colors.primary : colors.muted} />
      <Text style={[styles.modeText, { color: active ? colors.primary : colors.muted }]}>{label}</Text>
    </Pressable>
  );
}

export function StatusPill({ label, tone = "success" }: { label: string; tone?: "success" | "warning" | "muted" }) {
  const colors = useColors();
  const color = tone === "success" ? colors.success : tone === "warning" ? colors.warning : colors.muted;
  return (
    <View style={[styles.statusPill, { backgroundColor: `${color}18`, borderColor: `${color}55` }]}>
      <View style={[styles.statusDot, { backgroundColor: color }]} />
      <Text style={[styles.statusText, { color }]}>{label}</Text>
    </View>
  );
}

export const styles = StyleSheet.create({
  brandRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  brandMark: { width: 34, height: 34, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  brandName: { fontSize: 18, fontWeight: "700", letterSpacing: -0.4 },
  headingWrap: { gap: 6 },
  eyebrow: { fontSize: 11, fontWeight: "800", letterSpacing: 1.4 },
  heading: { fontSize: 28, fontWeight: "700", letterSpacing: -0.8, lineHeight: 34 },
  detail: { fontSize: 14, lineHeight: 21 },
  card: { borderWidth: 1, borderRadius: 20, padding: 16 },
  modeChip: { flexDirection: "row", alignItems: "center", gap: 7, borderWidth: 1, borderRadius: 999, paddingVertical: 9, paddingHorizontal: 12 },
  modeText: { fontSize: 12, fontWeight: "700" },
  pressed: { opacity: 0.72, transform: [{ scale: 0.98 }] },
  statusPill: { flexDirection: "row", alignItems: "center", gap: 6, borderWidth: 1, borderRadius: 999, paddingVertical: 6, paddingHorizontal: 9 },
  statusDot: { width: 6, height: 6, borderRadius: 3 },
  statusText: { fontSize: 11, fontWeight: "700" },
});
