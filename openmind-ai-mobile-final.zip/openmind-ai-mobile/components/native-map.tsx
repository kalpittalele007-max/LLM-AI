import MapView, { Marker, Polyline, type MapViewProps } from "react-native-maps";

type Coordinate = { latitude: number; longitude: number };
type Props = MapViewProps & { origin?: Coordinate | null; destination?: Coordinate | null; geometry?: Coordinate[]; colors: { primary: string } };

export function NativeMap({ origin, destination, geometry, colors, ...props }: Props) {
  return <MapView {...props}>{origin && <Marker coordinate={origin} title="You are here" pinColor={colors.primary} />}{destination && <Marker coordinate={destination} title="Destination" />}{geometry?.length ? <Polyline coordinates={geometry} strokeColor={colors.primary} strokeWidth={5} /> : null}</MapView>;
}
